
package tap_u4_ejercicio2_mysqlbasico;

public class Credencial {
    String numcontrol, nombrealumno, carrera, fechaexpedicion;
    int semestre;

    public Credencial(String numcontrol, String nombrealumno, String carrera, String echaexpedicion, int semestre) {
        this.numcontrol = numcontrol;
        this.nombrealumno = nombrealumno;
        this.carrera = carrera;
        this.fechaexpedicion = fechaexpedicion;
        this.semestre = semestre;
    }
    
    public String[] toRenglon(){
        String[] vector = new String[5];
        
        vector[0]=numcontrol;
        vector[1]=nombrealumno;
        vector[2]=carrera;
        vector[3]=fechaexpedicion;
        vector[4]=""+semestre;
        
        return vector;
        
    } 
}
