/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tap_u4_ejercicio2_mysqlbasico;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author josel
 */
public class BaseDatos {
    Connection conexion;
    Statement transaccion;
    ResultSet cursor;
    
    String cadenaConexion = "jdbc:mysql://bmhjh8qhlm83aeajuhoj-mysql.services.clever-cloud.com:3306/bmhjh8qhlm83aeajuhoj?zeroDateTimeBehavior=CONVERT_TO_NULL";
    String usuario = "u3yhskypba368z7s";
    String pass = "G1ck2Mk3lzDVdOYkTwqi";
    
    public BaseDatos(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection(cadenaConexion, usuario, pass);
            transaccion = conexion.createStatement();
        }catch(SQLException e){
            
        }catch(ClassNotFoundException e){
            
        }
    }
    
    public boolean insertar(Credencial c){
        String SQL_Insertar = "INSERT INTO `Escuela` (`numcontrol`, `nombrealumno`, `carrera`, `fechaexpedicion`, `semestre`) VALUES ('%NUM%', '%NOM%', '%CAR%', '%FEC%', '%SEM%');";
        SQL_Insertar = SQL_Insertar.replace("%NUM%", c.numcontrol);
        SQL_Insertar = SQL_Insertar.replace("%NOM%", c.nombrealumno);
        SQL_Insertar = SQL_Insertar.replace("%CAR%", c.carrera);
        SQL_Insertar = SQL_Insertar.replace("%FEC%", c.fechaexpedicion);
        SQL_Insertar = SQL_Insertar.replace("%SEM%", ""+c.semestre);

        try{
            transaccion.execute(SQL_Insertar);
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public ArrayList<Credencial> mostrarTodos(){
        ArrayList<Credencial> datos = new ArrayList<Credencial>();
        String SQL_consulta = "SELECT * FROM `Escuela`";
        
        try {
            //RESULTSET = variable que maneja las tuplas resultado
            cursor = transaccion.executeQuery(SQL_consulta);
            
            if(cursor.next()){
                do{
                    Credencial c = new Credencial(
                           cursor.getString(1),
                           cursor.getString(2),
                           cursor.getString(3),
                           cursor.getString(4),
                           cursor.getInt(5)
                   );
                   datos.add(c);
                }while(cursor.next());
            }
        } catch (SQLException ex) {
            Logger.getLogger(BaseDatos.class.getName()).log(Level.SEVERE, null, ex);
        }
        return datos;
    }
    
    public Credencial obtenerPorID(String NumaBuscar){
        String SQL_consulta = "SELECT * FROM `Escuela` WHERE 'numcontrol'="+NumaBuscar;
        
        try {
            //RESULTSET = variable que maneja las tuplas resultado
            cursor = transaccion.executeQuery(SQL_consulta);
            
            if(cursor.next()){
                    Credencial c = new Credencial(
                           cursor.getString(1),
                           cursor.getString(2),
                           cursor.getString(3),
                           cursor.getString(4),
                           cursor.getInt(5)
                   );
                   return c;
            }
        } catch (SQLException ex) {
            Logger.getLogger(BaseDatos.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new Credencial("","","","",-1);
    }
    
    public boolean eliminar(String NumaEliminar){
        String SQL_eliminar = "DELETE FROM `Escuela` WHERE `numcontrol`= "+NumaEliminar;
        
        try{
        transaccion.execute(SQL_eliminar);
        }catch(SQLException ex){
            return false;
        }
        return true;
    }
    
    public boolean actualizar(Credencial c){
        String SQL_actualizar = "UPDATE `Escuela` SET `numcontrol`='%NUM%', `nombrealumno`='%NOM%', `carrera`='%CAR%', `fechaexpedicion`='%FEC%', `semestre`='%SEM%' WHERE `numcontrol`="+c.numcontrol;
        SQL_actualizar = SQL_actualizar.replace("%NUM%", c.numcontrol);
        SQL_actualizar = SQL_actualizar.replace("%NOM%", c.nombrealumno);
        SQL_actualizar = SQL_actualizar.replace("%CAR%", c.carrera);
        SQL_actualizar = SQL_actualizar.replace("%FEC%", c.fechaexpedicion);
        SQL_actualizar = SQL_actualizar.replace("%SEM%", ""+c.semestre);

        try{
            transaccion.executeUpdate(SQL_actualizar);
        }catch(SQLException e){
            return false;
        }
        return true;
    }
}
